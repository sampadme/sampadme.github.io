<?php

namespace App\View\Components;

use Illuminate\View\Component;

class BackendDynamicColor extends Component
{
    public function render(){
        return view('backend.components.dynamic-color');
    }
}
