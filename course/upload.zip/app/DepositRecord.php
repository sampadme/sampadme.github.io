<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DepositRecord extends Model
{

}
